package exception;

public class InvalidEventTypeException extends Exception {
    public InvalidEventTypeException(String message) {
        super(message);
    }
}
