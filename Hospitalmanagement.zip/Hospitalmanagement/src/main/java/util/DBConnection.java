package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static Connection conn;

    public static Connection getConnection() {
        if (conn == null) {
            try {
                String url = PropertyUtil.getPropertyString("src/main/resources/db.properties");
                conn = DriverManager.getConnection(url);
            } catch (SQLException e) {
                System.out.println("SQL Exception: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Error getting DB connection: " + e.getMessage());
            }
        }
        return conn;
    }
}


